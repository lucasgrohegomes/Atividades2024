import React from 'react';

export default function container(){
    return(
        <section className='caixa'>
            <div className='caixinha1'>Item 1</div>
            <div className='caixinha2'>Item 2</div>
            <div className='caixinha3'>Item 3</div>
        </section>

    )
}