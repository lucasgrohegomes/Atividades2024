import React from 'react';

export default function botao(){
    return(
        <section className='secaobotao'>
        <button className="butao" onClick={function click(){alert(":D")}}>Eu sou um lindo botão</button>
        </section>
    )
}