function Header(){
    return(
        <header className="header">
        <h1>DOGOURMET, A MAIS FAMOSA FRANQUIA DE PRODUTOS GASTRÔNOMICOS DA ÁSIA<section></section></h1>
        </header>
    )
}

export default Header