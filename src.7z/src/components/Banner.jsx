export default function Banner(){
    return(
        <section className="banner">
            <img src="./bannerdogourmet.png" id="delicia"/>
        </section>
    )
}