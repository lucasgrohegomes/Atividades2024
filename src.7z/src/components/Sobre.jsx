export default function Sobre(){
    return(
        <section className="sobre">
            <h4>Esta é uma página sobre o maior restaurante da China, o favorito de Xi Jinping, o Dogourmet! Veja aqui abaixo o nosso cardápio!</h4>
        </section>
    )
}