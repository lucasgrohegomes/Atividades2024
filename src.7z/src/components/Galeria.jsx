export default function Galeria(){
    return(
        <>
        <div className="divG">
            <section className="galeria">
                <img src="/cachorroquente.jpg"/>
                <img src="/gourmet.jpg"/>
                <img src="/gigante.jpg"/>
                
            </section>
            <section className="galeria">
                <img src="/cadelo.jpg"/>
                <img src="/fantasia.jpg"/>
                <img src="/azul.jpg"></img>
            </section>
        </div>
    </>
    )
}